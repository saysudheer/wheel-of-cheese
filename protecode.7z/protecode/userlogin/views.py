from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404, get_list_or_404, reverse
from ftplib import FTP
from .models import Versions, Builds, Applications
import os


def home(request):
    return render(request, 'userlogin/home.html')


def user_login(request):
    context = {}
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return HttpResponseRedirect(reverse('user_dashboard'))
        else:
            context["error"] = "Provide valid credentials"
            return render(request, "userlogin/home.html", context)
    else:
        return render(request, "userlogin/home.html", context)
    pass


def success(request):
    context = {}
    context['user'] = request.user
    return render(request, "userlogin/dashboard.html", context)


def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('user_login'))


def gsaximport_ver(request):
    # connect to gsax and import versions
    print("in view")
    # Open ftp connection
    # socket.getaddrinfo('127.0.0.1', 80)
    print('username is as below')
    u = User.objects.all().first()
    user_name = request.user.username
    user_password = request.user.password
    print(user_name)
    print(user_password)

    ftp = FTP('127.0.0.1')
    ftp.login(user_name, 'password')
    ftp.cwd('/rtpgsa/projects/a/augusta/')
    fileslist = ftp.nlst()
    files = []
    for file in fileslist:
        try:
            if isinstance(float(file[:3]), float):
               files.append(file)
        except:
             pass
    print(files)
    context = {
        'title': 'Versions',
        'files': files
    }

    return render(request, 'userlogin/gsaximport.html', context)


def gsax_builds(request):

    # 1 get selected version from user input
    # 2 check if db already has version saved if saved ignore else save the version in db
    # 3 connect to gsax and list builds
    version = '2.1.0'
    r = Versions(version_no=version)
    r.save()
    # Open ftp connection
    # socket.getaddrinfo('127.0.0.1', 80)
    print('username is as below')
    u = User.objects.all().first()
    user_name = request.user.username
    user_password = request.user.password
    print(user_name)
    print(user_password)

    ftp = FTP('127.0.0.1')
    ftp.login(user_name, 'password')
    path = str(version)+'/ssrbd/'
    print(path)
    ftp.cwd(path)
    fileslist = ftp.nlst()
    files = []
    for file in fileslist:
        if len(file) == 3:
            files.append(file)
    print(files)
    context = {
        'title': 'Builds',
        'files': files
    }

    return render(request, 'userlogin/buildlist.html', context)


def gsax_apps(request):
    # 1 capture version and buildnumber from user
    # 2 validate if build and version is already in database if not insert
    # 3 list application names

    version = '2.1.0'
    buildnumber = '204'
    vid = Versions.objects.get(pk=1)
    print(vid)
    r = Builds(build_no=buildnumber,  version_id=vid)
    r.save()
    print("in view")
    # Open ftp connection
    # socket.getaddrinfo('127.0.0.1', 80)
    print('username is as below')
    u = User.objects.all().first()
    user_name = request.user.username
    user_password = request.user.password
    print(user_name)
    print(user_password)

    ftp = FTP('127.0.0.1')
    ftp.login(user_name, 'password')
    path = str(version)+'/ssrbd/'+str(buildnumber)
    print(path)
    ftp.cwd(path)
    fileslist = ftp.nlst()

    files = []
    for file in fileslist:
        if file.endswith('gz') or file.endswith('tgz') or file.endswith('qcow2'):
            files.append(file)
    print(files)
    context = {
        'title': 'Builds',
        'files': files
    }

    return render(request, 'userlogin/appslist.html', context)


def gsax_appfiles(request):

    # 1 Capture version,build and application name
    # 2 validate with db to prevent duplicate and insert
    # 3 list csv files and highlight files already imported

    # alternative steps
    # here upon selecting application, we can import csv files
    # to local media folder and
    # when user clicks on application name we can display reports

    version = '2.1.0'
    buildnumber = '204'
    applicationname = 'lnvgy_sw_lxca_204-2.1.0_kvm_x86-64.qcow2'
    filename, file_extension = os.path.splitext(applicationname)
    applicationname = filename
    # Open ftp connection
    # socket.getaddrinfo('127.0.0.1', 80)
    print('username is as below')
    u = User.objects.all().first()
    user_name = request.user.username
    user_password = request.user.password
    print(user_name)
    print(user_password)

     ftp = FTP('127.0.0.1')
    ftp.login(user_name, 'password')
    path = str(version)+'/ssrbd/'+str(buildnumber)
    print(path)
    ftp.cwd(path)
    fileslist = ftp.nlst()
    print(fileslist)
    files = []
    print(applicationname + '_components.csv')
    for file in fileslist:
        if (file == applicationname+'_components.csv') or (file == applicationname+'_vulnerabilities.csv'):
            files.append(file)

    for filename in files:
        #fs = FileSystemStorage()
        local_filename = os.path.join(r"d:\myfolder", filename)
        lf = open(local_filename, "wb")
        ftp.retrbinary("RETR " + filename, lf.write, 8 * 1024)
        lf.close()

    print(files)
    context = {
        'title': 'csv files',
        'files': files
    }

    return render(request, 'userlogin/appfiles.html', context)
# write one more view here to download files gsax and save to local media folder
# this view should also list report of both csv files

#


def user_files(request):

    applist = Applications.objects.all()
    print(applist)
    context = {
        'title': 'User files',
        'files': applist
    }

    return render(request, 'userlogin/userfiles.html', context)


def reports(request):

    context = {
        'title': 'Reports',
        'files': ""
    }

    return render(request, 'userlogin/reports.html', context)
