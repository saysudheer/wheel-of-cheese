from django.contrib import admin
from .models import Versions, Builds, Applications


admin.site.register(Versions)
admin.site.register(Builds)
admin.site.register(Applications)
