from django.urls import path
from . import views


urlpatterns = [
    path('protecode/', views.home, name='home'),
    path('protecode/login/', views.user_login, name="user_login"),
    path('protecode/dashboard/', views.success, name="user_dashboard"),
    path('protecode/logout/', views.user_logout, name="user_logout"),
    path('protecode/dashboard/gsaximport', views.gsaximport_ver, name='gsax_verisonlist'),
    path('protecode/dashboard/importfromversions', views.gsax_builds, name='gsax_buildlist'),
    path('protecode/dashboard/applist', views.gsax_apps, name='gsax_apps'),
    path('protecode/dashboard/appfiles', views.gsax_appfiles, name='gsax_apps'),
    path('protecode/dashboard/userfiles', views.user_files, name='user_files'),
    path('protecode/dashboard/reports', views.reports, name='user_reports'),

]
