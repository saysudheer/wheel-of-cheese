from django.db import models


class Versions(models.Model):
    version_no = models.CharField(max_length=7)

    def __str__(self):
        return self.version_no


class Builds(models.Model):
    build_no = models.CharField(max_length=5)
    version_id = models.ForeignKey(Versions, on_delete=models.CASCADE)

    def __str__(self):
        return self.build_no


class Applications(models.Model):
    application_name = models.CharField(max_length=100)
    components_csv = models.CharField(max_length=500)
    vuln_csv = models.CharField(max_length=500)
    build_id = models.ForeignKey(Builds, on_delete=models.CASCADE)

    def __str__(self):
        return self.application_name

